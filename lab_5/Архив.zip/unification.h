#pragma once

struct Atom;

bool Unify(const Atom& atom1, const Atom& atom2);
