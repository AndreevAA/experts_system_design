#pragma once

#include <string>
#include <string_view>

using Name = std::string;
using NameSV = std::string_view;
